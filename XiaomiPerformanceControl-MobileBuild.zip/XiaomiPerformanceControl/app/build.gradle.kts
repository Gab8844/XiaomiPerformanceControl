plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "fr.xiaomi.performance"
    compileSdk = 35

    defaultConfig {
        applicationId = "fr.xiaomi.performance"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }
}
