package fr.xiaomi.performance

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import javax.microedition.khronos.egl.EGL10
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.egl.EGLContext
import javax.microedition.khronos.egl.EGLDisplay
import javax.microedition.khronos.opengles.GL10
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File
import java.util.Locale
import kotlin.math.max

class MainActivity : Activity() {
    private val bg = Color.rgb(16, 17, 20)
    private val panel = Color.rgb(29, 31, 36)
    private val muted = Color.rgb(160, 166, 178)
    private val accent = Color.rgb(130, 175, 255)
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var ramValue: TextView
    private lateinit var ramDetail: TextView
    private lateinit var cpuValue: TextView
    private lateinit var cpuDetail: TextView
    private lateinit var freqValue: TextView
    private lateinit var gpuValue: TextView
    private lateinit var gpuDetail: TextView
    private lateinit var thermalValue: TextView
    private lateinit var deviceValue: TextView
    private lateinit var statusValue: TextView
    private var previousCpu = readCpuStat()

    private val updater = object : Runnable {
        override fun run() {
            refreshMetrics()
            handler.postDelayed(this, 2000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
        refreshMetrics()
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(updater)
        handler.post(updater)
    }

    override fun onPause() {
        handler.removeCallbacks(updater)
        super.onPause()
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg); clipToPadding = false }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(28))
        }
        scroll.addView(root)

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val heading = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        heading.addView(text("PERFORMANCE CONTROL", 12, accent, true))
        heading.addView(text("Centre de performances", 24, Color.WHITE, true).apply { setPadding(0, dp(4), 0, 0) })
        top.addView(heading)
        val refresh = button("Actualiser") { refreshMetrics() }
        top.addView(refresh)
        root.addView(top)
        root.addView(text("Xiaomi • Mode Advanced sans root", 13, muted, false).apply { setPadding(0, dp(8), 0, dp(18)) })

        val hero = card()
        hero.addView(text("ÉTAT DU TÉLÉPHONE", 11, muted, true))
        deviceValue = text("Lecture des informations…", 18, Color.WHITE, true).apply { setPadding(0, dp(9), 0, dp(4)) }
        hero.addView(deviceValue)
        statusValue = text("Mesures actualisées automatiquement", 12, muted, false)
        hero.addView(statusValue)
        root.addView(hero, marginBottom())

        val ram = card()
        ram.addView(sectionTitle("RAM", "Mémoire vive"))
        ramValue = text("--", 30, Color.WHITE, true).apply { setPadding(0, dp(12), 0, dp(3)) }
        ram.addView(ramValue)
        ramDetail = text("Lecture de la mémoire…", 13, muted, false)
        ram.addView(ramDetail)
        root.addView(ram, marginBottom())

        val cpu = card()
        cpu.addView(sectionTitle("CPU", "Processeur"))
        cpuValue = text("--", 30, Color.WHITE, true).apply { setPadding(0, dp(12), 0, dp(3)) }
        cpu.addView(cpuValue)
        cpuDetail = text("Utilisation globale estimée", 13, muted, false)
        cpu.addView(cpuDetail)
        freqValue = text("Fréquences : lecture en cours…", 13, muted, false).apply { setPadding(0, dp(10), 0, 0) }
        cpu.addView(freqValue)
        root.addView(cpu, marginBottom())

        val gpu = card()
        gpu.addView(sectionTitle("GPU", "Graphismes"))
        gpuValue = text("Identification en cours…", 19, Color.WHITE, true).apply { setPadding(0, dp(12), 0, dp(4)) }
        gpu.addView(gpuValue)
        gpuDetail = text("La charge GPU n’est pas exposée sur tous les appareils.", 13, muted, false)
        gpu.addView(gpuDetail)
        root.addView(gpu, marginBottom())

        val thermal = card()
        thermal.addView(sectionTitle("THERMIQUE", "Température et état système"))
        thermalValue = text("Lecture thermique…", 17, Color.WHITE, true).apply { setPadding(0, dp(12), 0, dp(4)) }
        thermal.addView(thermalValue)
        root.addView(thermal, marginBottom())

        val tools = card()
        tools.addView(text("OUTILS ANDROID", 11, muted, true))
        tools.addView(text("Les actions ci-dessous ouvrent les réglages système. Android ne permet pas à une application ordinaire de forcer les fréquences CPU/GPU ni de vider la RAM des autres applications.", 13, muted, false).apply { setPadding(0, dp(8), 0, dp(14)) })
        tools.addView(actionButton("Économie de batterie", "Ouvrir les réglages batterie") {
            openSettings(Settings.ACTION_BATTERY_SAVER_SETTINGS)
        })
        tools.addView(actionButton("Informations des applications", "Gérer les applications") {
            openSettings(Settings.ACTION_APPLICATION_SETTINGS)
        })
        tools.addView(actionButton("Options développeur", "Ouvrir si disponibles") {
            openSettings(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)
        })
        root.addView(tools, marginBottom())

        root.addView(text("Données locales • Actualisation toutes les 2 secondes • Aucune collecte ni transmission", 11, muted, false).apply {
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(6), dp(8), dp(8))
        })
        setContentView(scroll)
    }

    private fun sectionTitle(tag: String, subtitle: String): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val left = text(tag, 12, accent, true)
        row.addView(left)
        row.addView(text("  ·  $subtitle", 13, muted, false))
        return row
    }

    private fun refreshMetrics() {
        if (!::ramValue.isInitialized) return
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val total = mi.totalMem
        val available = mi.availMem
        val used = max(0L, total - available)
        val pct = if (total > 0) (used * 100 / total).toInt() else 0
        ramValue.text = "$pct % utilisé"
        ramDetail.text = "${formatBytes(used)} utilisés  •  ${formatBytes(available)} disponibles  •  ${formatBytes(total)} au total"

        val nowCpu = readCpuStat()
        val old = previousCpu
        if (nowCpu != null && old != null) {
            val totalDelta = nowCpu.first - old.first
            val idleDelta = nowCpu.second - old.second
            val usage = if (totalDelta > 0) (((totalDelta - idleDelta).toDouble() / totalDelta) * 100).toInt().coerceIn(0, 100) else 0
            cpuValue.text = "$usage % d’activité"
        } else cpuValue.text = "Indisponible"
        previousCpu = nowCpu
        val cores = Runtime.getRuntime().availableProcessors()
        cpuDetail.text = "$cores cœurs détectés • mesure globale depuis /proc/stat"
        val freqs = (0 until cores).mapNotNull { core ->
            val f = readLong("/sys/devices/system/cpu/cpu$core/cpufreq/scaling_cur_freq")
            if (f != null && f > 0) f / 1000 else null
        }
        freqValue.text = if (freqs.isNotEmpty()) "Fréquences instantanées : ${freqs.minOrNull()}–${freqs.maxOrNull()} MHz (cœurs exposés)" else "Fréquences CPU : accès non exposé par le système"

        val gpuName = readGpuName()
        gpuValue.text = gpuName ?: "Informations GPU limitées"
        gpuDetail.text = "OpenGL ES : ${getGlVersion()} • Charge GPU : non fournie par l’API Android standard"

        val battery = registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val batteryTemp = battery?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        val tempText = if (batteryTemp > 0) String.format(Locale.FRANCE, "Batterie : %.1f °C", batteryTemp / 10f) else "Température batterie indisponible"
        val power = getSystemService(Context.POWER_SERVICE) as PowerManager
        val thermal = if (Build.VERSION.SDK_INT >= 29) {
            when (power.currentThermalStatus) {
                PowerManager.THERMAL_STATUS_NONE -> "normal"
                PowerManager.THERMAL_STATUS_LIGHT -> "léger"
                PowerManager.THERMAL_STATUS_MODERATE -> "modéré"
                PowerManager.THERMAL_STATUS_SEVERE -> "élevé"
                PowerManager.THERMAL_STATUS_CRITICAL -> "critique"
                PowerManager.THERMAL_STATUS_EMERGENCY -> "urgence"
                PowerManager.THERMAL_STATUS_SHUTDOWN -> "arrêt thermique"
                else -> "inconnu"
            }
        } else "non disponible sur cette version Android"
        thermalValue.text = "$tempText  •  État thermique : $thermal"
        deviceValue.text = "${Build.MANUFACTURER} ${Build.MODEL}"
        statusValue.text = "Android ${Build.VERSION.RELEASE} • ${if (mi.lowMemory) "Mémoire faible signalée" else "État mémoire normal"}"
    }

    private fun readCpuStat(): Pair<Long, Long>? = try {
        val parts = File("/proc/stat").readLines().first().trim().split(Regex("\\s+"))
        val values = parts.drop(1).take(8).map { it.toLong() }
        val total = values.sum()
        val idle = values[3] + values.getOrElse(4) { 0L }
        total to idle
    } catch (_: Exception) { null }

    private fun readLong(path: String): Long? = try { File(path).readText().trim().toLongOrNull() } catch (_: Exception) { null }

    private fun readGpuName(): String? {
        val candidates = listOf("/sys/class/kgsl/kgsl-3d0/gpu_model")
        for (path in candidates) {
            try {
                val value = File(path).readText().trim()
                if (value.isNotBlank()) return value
            } catch (_: Exception) { }
        }
        // EGL creates a tiny off-screen OpenGL ES context to read the real renderer string.
        var egl: EGL10? = null
        var display: EGLDisplay? = null
        var surface: javax.microedition.khronos.egl.EGLSurface? = null
        var context: EGLContext? = null
        try {
            egl = EGLContext.getEGL() as EGL10
            display = egl.eglGetDisplay(EGL10.EGL_DEFAULT_DISPLAY)
            if (display == EGL10.EGL_NO_DISPLAY) return null
            if (!egl.eglInitialize(display, IntArray(2))) return null
            val attrs = intArrayOf(EGL10.EGL_RED_SIZE, 8, EGL10.EGL_GREEN_SIZE, 8,
                EGL10.EGL_BLUE_SIZE, 8, EGL10.EGL_SURFACE_TYPE, EGL10.EGL_PBUFFER_BIT, EGL10.EGL_NONE)
            val configs = arrayOfNulls<EGLConfig>(1)
            val count = IntArray(1)
            if (!egl.eglChooseConfig(display, attrs, configs, 1, count) || count[0] == 0) return null
            val config = configs[0] ?: return null
            context = egl.eglCreateContext(display, config, EGL10.EGL_NO_CONTEXT,
                intArrayOf(0x3098, 2, EGL10.EGL_NONE))
            surface = egl.eglCreatePbufferSurface(display, config,
                intArrayOf(EGL10.EGL_WIDTH, 1, EGL10.EGL_HEIGHT, 1, EGL10.EGL_NONE))
            if (context == EGL10.EGL_NO_CONTEXT || surface == EGL10.EGL_NO_SURFACE) return null
            if (!egl.eglMakeCurrent(display, surface, surface, context)) return null
            val gl = context.gl as GL10
            val renderer = gl.glGetString(GL10.GL_RENDERER)
            val vendor = gl.glGetString(GL10.GL_VENDOR)
            return listOfNotNull(renderer, vendor?.takeIf { !it.equals(renderer, true) }).joinToString(" • ").ifBlank { null }
        } catch (_: Exception) {
            return null
        } finally {
            try {
                if (egl != null && display != null) {
                    egl.eglMakeCurrent(display, EGL10.EGL_NO_SURFACE, EGL10.EGL_NO_SURFACE, EGL10.EGL_NO_CONTEXT)
                    if (surface != null && surface != EGL10.EGL_NO_SURFACE) egl.eglDestroySurface(display, surface)
                    if (context != null && context != EGL10.EGL_NO_CONTEXT) egl.eglDestroyContext(display, context)
                    egl.eglTerminate(display)
                }
            } catch (_: Exception) { }
        }
    }

    private fun getGlVersion(): String = try {
        val info = packageManager.getSystemAvailableFeatures().firstOrNull { it.name == null && it.reqGlEsVersion > 0 }
        info?.let { "${(it.reqGlEsVersion shr 16) and 0xffff}.${it.reqGlEsVersion and 0xffff}" } ?: "inconnue"
    } catch (_: Exception) { "inconnue" }

    private fun formatBytes(bytes: Long): String {
        val gb = bytes / (1024.0 * 1024.0 * 1024.0)
        return if (gb >= 1) String.format(Locale.FRANCE, "%.2f Go", gb) else String.format(Locale.FRANCE, "%.0f Mo", bytes / (1024.0 * 1024.0))
    }

    private fun openSettings(action: String) {
        try { startActivity(Intent(action)) } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(17), dp(17), dp(17), dp(17))
        background = rounded(panel, 22)
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean): TextView = TextView(this).apply {
        text = value
        textSize = size.toFloat()
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun button(label: String, click: () -> Unit): Button = Button(this).apply {
        text = label
        textSize = 12f
        isAllCaps = false
        setTextColor(Color.WHITE)
        background = rounded(Color.rgb(49, 77, 120), 16)
        setPadding(dp(10), 0, dp(10), 0)
        setOnClickListener { click() }
    }

    private fun actionButton(title: String, subtitle: String, click: () -> Unit): View {
        val b = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(13), dp(11), dp(13), dp(11))
            background = rounded(Color.rgb(39, 42, 49), 15)
            setOnClickListener { click() }
        }
        b.addView(text(title, 15, Color.WHITE, true))
        b.addView(text(subtitle, 12, muted, false).apply { setPadding(0, dp(3), 0, 0) })
        val lp = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }
        b.layoutParams = lp
        return b
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun marginBottom(): LinearLayout.LayoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) }
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
