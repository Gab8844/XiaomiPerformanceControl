# Xiaomi Performance Control

Application Android native Kotlin, interface sombre inspirée d'HyperOS, sans root.

## Fonctions
- RAM : mémoire totale, utilisée et disponible via `ActivityManager.MemoryInfo`.
- CPU : estimation de charge globale depuis `/proc/stat`, nombre de cœurs et fréquences `scaling_cur_freq` lorsque les fichiers sont accessibles.
- GPU : identifiant matériel disponible et informations OpenGL ES déclarées par Android. Android ne fournit pas d'API publique universelle pour la charge GPU.
- Thermique : état thermique Android et température de batterie si le système la publie.
- Raccourcis vers les réglages Android batterie, applications et options développeur.
- Actualisation automatique toutes les deux secondes. Aucune donnée n'est envoyée sur Internet.

## Limites importantes (sans root)
Cette application ne peut pas modifier les fréquences CPU/GPU, les tensions, les gouverneurs, les limites thermiques ou tuer les processus d'autres applications. Ces opérations sont protégées par Android et/ou le noyau constructeur. Les fréquences et certaines informations GPU peuvent être masquées par HyperOS ; dans ce cas l'application affiche explicitement leur indisponibilité.

## Construire l'APK
1. Installer Android Studio (version récente) avec Android SDK Platform 35 et JDK 17 ou 21.
2. Ouvrir ce dossier `XiaomiPerformanceControl` dans Android Studio.
3. Laisser Gradle synchroniser les dépendances/plugins.
4. Choisir **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. L'APK debug sera généré dans `app/build/outputs/apk/debug/app-debug.apk`.

Ou depuis un terminal avec Gradle 8.9 installé :

```bash
gradle assembleDebug
```

`applicationId`: `fr.xiaomi.performance`  
`minSdk`: 26  
`targetSdk`: 35  
`version`: 1.0.0
